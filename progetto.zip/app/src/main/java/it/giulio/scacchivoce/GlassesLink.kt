package it.giulio.scacchivoce

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.meta.wearable.dat.camera.Camera
import com.meta.wearable.dat.camera.addCamera
import com.meta.wearable.dat.camera.types.StreamConfiguration
import com.meta.wearable.dat.camera.types.StreamState
import com.meta.wearable.dat.camera.types.VideoFrame
import com.meta.wearable.dat.camera.types.VideoQuality
import com.meta.wearable.dat.core.Wearables
import com.meta.wearable.dat.core.selectors.AutoDeviceSelector
import com.meta.wearable.dat.core.session.DeviceSession
import com.meta.wearable.dat.core.session.DeviceSessionState
import com.meta.wearable.dat.core.types.Permission
import com.meta.wearable.dat.core.types.PermissionStatus
import com.meta.wearable.dat.core.types.RegistrationState
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Collega gli occhiali Ray-Ban Meta alla pagina.
 * La pagina chiama GlassesBridge.start(), poi legge i fotogrammi con GlassesBridge.frame():
 * "numero,larghezza,altezza,base64" in scala di grigi a metà risoluzione.
 * GlassesBridge.speak() usa la voce di Android: se gli occhiali sono collegati in Bluetooth, si sente da lì.
 */
class GlassesLink(private val act: MainActivity) {
  @Volatile private var status = ""
  private val latest = AtomicReference<String?>(null)
  @Volatile private var seq = 0
  @Volatile private var lastFrameAt = 0L

  private var initialized = false
  private var wanted = false
  private var askedRegistration = false
  private var registration: RegistrationState? = null
  private var session: DeviceSession? = null
  private var camera: Camera? = null
  private val jobs = mutableListOf<Job>()

  private var tts: TextToSpeech? = null
  @Volatile private var ttsReady = false

  init {
    tts =
        TextToSpeech(act) { result ->
          if (result == TextToSpeech.SUCCESS) {
            tts?.language = Locale.ITALIAN
            ttsReady = true
          }
        }
  }

  inner class Bridge {
    @JavascriptInterface fun available(): Boolean = true

    @JavascriptInterface fun start() = act.runOnUiThread { begin() }

    @JavascriptInterface fun stop() = act.runOnUiThread { end() }

    @JavascriptInterface fun status(): String = status

    @JavascriptInterface fun frame(): String = latest.get() ?: ""

    @JavascriptInterface fun speak(text: String) = act.runOnUiThread { say(text) }
  }

  val bridge = Bridge()

  private fun say(text: String) {
    if (!ttsReady) return
    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mossa")
  }

  // ---- 1. permessi Android ----
  private fun begin() {
    wanted = true
    status = "Controllo i permessi Bluetooth…"
    val ok =
        ContextCompat.checkSelfPermission(act, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    if (ok) onAndroidPermissions(true)
    else act.bluetoothPermissions.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
  }

  fun onAndroidPermissions(granted: Boolean) {
    if (!wanted) return
    if (!granted) {
      status = "Serve il permesso Bluetooth per parlare con gli occhiali."
      return
    }
    // ---- 2. collegamento con l'app Meta AI ----
    if (!initialized) {
      initialized = true
      Wearables.initialize(act.applicationContext).onFailure { error, _ ->
        status = "Non riesco ad avviare il collegamento: ${error.description}"
      }
      jobs += act.lifecycleScope.launch { Wearables.registrationState.collect { onRegistration(it) } }
    } else {
      registration?.let { onRegistration(it) }
    }
  }

  private fun onRegistration(state: RegistrationState) {
    registration = state
    if (!wanted) return
    when (state) {
      RegistrationState.REGISTERED -> checkGlassesCamera()
      RegistrationState.REGISTERING -> status = "Conferma il collegamento nell'app Meta AI…"
      RegistrationState.UNAVAILABLE -> status = "Serve l'app Meta AI con la modalità sviluppatore attiva."
      else -> {
        status = "Apro l'app Meta AI per collegare gli occhiali…"
        if (!askedRegistration) {
          askedRegistration = true
          Wearables.startRegistration(act)
        }
      }
    }
  }

  // ---- 3. permesso fotocamera degli occhiali ----
  private fun checkGlassesCamera() {
    if (session != null) return
    status = "Controllo il permesso della fotocamera degli occhiali…"
    act.lifecycleScope.launch {
      Wearables.checkPermissionStatus(Permission.CAMERA)
          .onSuccess { s ->
            if (s == PermissionStatus.Granted) openSession()
            else {
              status = "Concedi la fotocamera degli occhiali nell'app Meta AI…"
              act.glassesCameraPermission.launch(Permission.CAMERA)
            }
          }
          .onFailure { error, _ -> status = "Errore sui permessi: ${error.description}" }
    }
  }

  fun onGlassesCameraPermission(s: PermissionStatus) {
    if (!wanted) return
    if (s == PermissionStatus.Granted) openSession()
    else status = "Senza il permesso della fotocamera degli occhiali non posso vedere la scacchiera."
  }

  // ---- 4. sessione e video ----
  private fun openSession() {
    if (session != null) return
    status = "Accendo la fotocamera degli occhiali…"
    Wearables.createSession(AutoDeviceSelector())
        .fold(
            onSuccess = { s ->
              session = s
              jobs += act.lifecycleScope.launch { s.errors.collect { e -> status = "Occhiali: ${e.description}" } }
              jobs +=
                  act.lifecycleScope.launch {
                    s.state.collect { st -> if (st == DeviceSessionState.STARTED && camera == null) addCamera(s) }
                  }
              s.start()
              Unit
            },
            onFailure = { error, _ ->
              status = "Non trovo gli occhiali: ${error.description}"
              Unit
            },
        )
  }

  private fun addCamera(s: DeviceSession) {
    s.addCamera(StreamConfiguration(videoQuality = VideoQuality.MEDIUM, frameRate = 15))
        .fold(
            onSuccess = { cam ->
              camera = cam
              jobs += act.lifecycleScope.launch(Dispatchers.Default) { cam.stream.videoStream.collect { onFrame(it) } }
              jobs +=
                  act.lifecycleScope.launch {
                    cam.stream.state.collect { st ->
                      status =
                          when (st) {
                            StreamState.STREAMING -> "In diretta dagli occhiali"
                            StreamState.PAUSED -> "Video in pausa: tocca la stanghetta degli occhiali per riprendere"
                            StreamState.STOPPED,
                            StreamState.CLOSED -> "Video degli occhiali fermo"
                            else -> "Avvio il video…"
                          }
                    }
                  }
              cam.stream.start().onFailure { error, _ -> status = "Il video non parte: ${error.description}" }
              Unit
            },
            onFailure = { error, _ ->
              status = "Fotocamera degli occhiali non disponibile: ${error.description}"
              Unit
            },
        )
  }

  // Tengo solo la luminosità (piano Y del video) a metà risoluzione, al massimo ~10 fotogrammi al secondo
  private fun onFrame(f: VideoFrame) {
    if (f.isCompressed) return
    val now = SystemClock.elapsedRealtime()
    if (now - lastFrameAt < 90) return
    lastFrameAt = now
    val w = f.width
    val h = f.height
    if (w < 4 || h < 4) return
    val buf = f.buffer.duplicate()
    val total = buf.remaining()
    if (total < w * h) return
    var stride = w
    val guess = total * 2 / (3 * h)
    if (guess >= w && guess * h * 3 / 2 == total) stride = guess
    val luma = ByteArray(stride * (h - 1) + w)
    buf.get(luma, 0, luma.size)
    val ow = w / 2
    val oh = h / 2
    val out = ByteArray(ow * oh)
    for (j in 0 until oh) {
      val r0 = 2 * j * stride
      val r1 = r0 + stride
      for (i in 0 until ow) {
        val a =
            (luma[r0 + 2 * i].toInt() and 255) + (luma[r0 + 2 * i + 1].toInt() and 255) +
                (luma[r1 + 2 * i].toInt() and 255) + (luma[r1 + 2 * i + 1].toInt() and 255)
        out[j * ow + i] = (a shr 2).toByte()
      }
    }
    seq += 1
    latest.set("$seq,$ow,$oh," + Base64.encodeToString(out, Base64.NO_WRAP))
  }

  private fun end() {
    wanted = false
    camera?.stop()
    camera = null
    session?.stop()
    session = null
    latest.set(null)
    status = ""
  }

  fun shutdown() {
    end()
    jobs.forEach { it.cancel() }
    jobs.clear()
    tts?.shutdown()
    tts = null
  }
}
