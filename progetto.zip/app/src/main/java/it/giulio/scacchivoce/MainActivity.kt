package it.giulio.scacchivoce

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.meta.wearable.dat.core.Wearables
import com.meta.wearable.dat.core.types.PermissionStatus

/**
 * Tutta l'app è la pagina "Scacchi a Voce" dentro una WebView.
 * - La fotocamera del telefono arriva alla pagina dal vivo (niente foto).
 * - Gli occhiali Ray-Ban Meta passano dal ponte GlassesBridge (vedi GlassesLink).
 */
class MainActivity : ComponentActivity() {
  private lateinit var web: WebView
  private lateinit var glasses: GlassesLink
  private var pendingWebPermission: PermissionRequest? = null

  // Permesso fotocamera del telefono, chiesto quando la pagina accende la fotocamera
  private val phoneCameraPermission =
      registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val req = pendingWebPermission
        pendingWebPermission = null
        if (req != null) {
          if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else req.deny()
        }
      }

  // Permessi Bluetooth per parlare con gli occhiali
  val bluetoothPermissions =
      registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        glasses.onAndroidPermissions(result.values.all { it })
      }

  // Permesso della fotocamera degli occhiali, chiesto dentro l'app Meta AI
  val glassesCameraPermission =
      registerForActivityResult(Wearables.RequestPermissionContract()) { result ->
        glasses.onGlassesCameraPermission(result.getOrDefault(PermissionStatus.Denied))
      }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    glasses = GlassesLink(this)

    val loader =
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

    web = WebView(this)
    web.setBackgroundColor(Color.parseColor("#07040F"))
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.settings.mediaPlaybackRequiresUserGesture = false
    web.webViewClient =
        object : WebViewClient() {
          override fun shouldInterceptRequest(
              view: WebView,
              request: WebResourceRequest,
          ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
    web.webChromeClient =
        object : WebChromeClient() {
          override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
              if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                val ok =
                    ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.CAMERA,
                    ) == PackageManager.PERMISSION_GRANTED
                if (ok) {
                  request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                } else {
                  pendingWebPermission = request
                  phoneCameraPermission.launch(Manifest.permission.CAMERA)
                }
              } else {
                request.deny()
              }
            }
          }
        }
    web.addJavascriptInterface(glasses.bridge, "GlassesBridge")

    // La pagina resta fuori dalle barre di sistema
    val root = FrameLayout(this)
    root.setBackgroundColor(Color.parseColor("#07040F"))
    root.addView(web, FrameLayout.LayoutParams(-1, -1))
    ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
      val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
      v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
      WindowInsetsCompat.CONSUMED
    }
    setContentView(root)

    if (savedInstanceState != null) web.restoreState(savedInstanceState)
    else web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
  }

  override fun onSaveInstanceState(outState: Bundle) {
    super.onSaveInstanceState(outState)
    web.saveState(outState)
  }

  // L'app Meta AI ci riporta qui (scacchivoce://) dopo il collegamento: la pagina resta com'era
  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
  }

  override fun onDestroy() {
    glasses.shutdown()
    web.destroy()
    super.onDestroy()
  }
}
