import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "it.giulio.scacchivoce"
  compileSdk = 36

  defaultConfig {
    applicationId = "it.giulio.scacchivoce"
    minSdk = 31
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"
    // Modalità sviluppatore dell'app Meta AI: gli identificativi possono restare "0"
    manifestPlaceholders["mwdat_application_id"] = "0"
    manifestPlaceholders["mwdat_client_token"] = "0"
  }

  buildTypes {
    release { isMinifyEnabled = false }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }
}

kotlin { compilerOptions { jvmTarget = JvmTarget.JVM_17 } }

dependencies {
  implementation("androidx.activity:activity-ktx:1.10.1")
  implementation("androidx.core:core-ktx:1.16.0")
  implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
  implementation("androidx.webkit:webkit:1.13.0")
  implementation("com.meta.wearable:mwdat-core:1.0.1")
  implementation("com.meta.wearable:mwdat-camera:1.0.1")
}
