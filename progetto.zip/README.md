# Scacchi a Voce (Android + Ray-Ban Meta)

App Android che mostra la pagina "Scacchi a Voce" e prende il video dalla fotocamera del telefono
o dagli occhiali Ray-Ban Meta (Meta Wearables Device Access Toolkit 1.0.1). Riconosce le mosse sulla
scacchiera vera e dice a voce la mossa migliore.

- La pagina è in `app/src/main/assets/www/index.html`.
- Il collegamento agli occhiali è in `GlassesLink.kt`.
- Ogni push su `main` costruisce l'APK con GitHub Actions e lo mette nella release "ultima".

Per usare gli occhiali serve l'app Meta AI con la modalità sviluppatore attiva.
